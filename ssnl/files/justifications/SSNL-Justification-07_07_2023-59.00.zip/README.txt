PLEASE READ

You are absolute magic!