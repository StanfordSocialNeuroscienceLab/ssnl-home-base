PLEASE READ

You're doing great!